module.exports = require('./src/LinkedinClient');
