declare module 'all-the-cities';
